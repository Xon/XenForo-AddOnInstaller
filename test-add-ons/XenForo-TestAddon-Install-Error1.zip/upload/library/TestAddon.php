<?php

class TestAddon
{
    public function install()
    {
    }
}