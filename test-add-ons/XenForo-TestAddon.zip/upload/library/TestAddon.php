<?php

class TestAddon
{
    public static function install()
    {
    }
}