<?php

class TestAddon
{
    public static function install()
    {
        throw new Exception("Testing");
    }
}